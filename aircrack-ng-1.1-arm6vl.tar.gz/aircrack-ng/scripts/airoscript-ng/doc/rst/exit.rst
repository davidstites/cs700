Exit
-----

Quitting airoscript will ask you if you want it to delete temp data and virtual interfaces.

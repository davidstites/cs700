char pcap_version[] = "1.2.1";
